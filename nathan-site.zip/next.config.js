/** @type {import('next').NextConfig} */
const nextConfig = {
  // Configurações do Next.js 14
}

module.exports = nextConfig 